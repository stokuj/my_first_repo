﻿
#include <iostream>

int main()
{
	double a, b, c;
	double delta, sqrt_delta;
	double  x1, x2;

	std::cout << "Enter a,b and c:\n";
	std::cin >> a >> b >> c;

	delta = ((b * b) - 4 * a * c);




	if (delta > 0)
	{
		sqrt_delta = sqrt(delta);
		std::cout << "Delta > 0 \n";


		x1 = ((-b + sqrt_delta) / (2 * a));
		x2 = ((-b - sqrt_delta) / (2 * a));


		std::cout << "X1: " << x1 << std::endl << "X2: " << x2 << std::endl;
	}


	if (delta == 0)
	{

		std::cout << "Delta = 0 \n";


		x1 = (-b / (2 * a));


		std::cout << "X0: " << x1 << std::endl;
	}


	if (delta < 0)
	{
		sqrt_delta = sqrt(-delta);
		std::cout << "Delta < 0 \n";


		x1 = (-b / (2 * a));
		x2 = (sqrt_delta / (2 * a));


		std::cout << "X1: " << x1 << " + " << x2 << "i\n";
		std::cout << "X2: " << x1 << " - " << x2 << "i";
	}

	return 0;
}
