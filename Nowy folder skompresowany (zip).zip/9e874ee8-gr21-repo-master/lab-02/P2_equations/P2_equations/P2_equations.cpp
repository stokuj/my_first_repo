﻿
#include <iostream>

int main()
{
	int x1, x2;
	int a11, a12;
	int a21, a22;
	int b1, b2;
	int w, wx1, wx2;

    std::cout << "Enter a11: \n";
	std::cin >> a11;

	std::cout << "Enter a12: \n";
	std::cin >> a12;

	std::cout << "Enter a21: \n";
	std::cin >> a21;

	std::cout << "Enter a22: \n";
	std::cin >> a22;

	std::cout << "Enter b1: \n";
	std::cin >> b1;

	std::cout << "Enter b2: \n";
	std::cin >> b2;

	w = a11 * a22 - a21 * a12;
	wx1 = b1 * a22 - b2 * a12;
	wx2 = b2 * a11 - b1 * a21;

	if (w != 0) {
		x1 = wx1 / w;
		x2 = wx2 / w;
	
		std::cout << x1 << " " << x2;
	}
	else
	{

		if (wx1 == 0 && wx2 == 0)
		{
			std::cout << "infinitely many solutions";
		}

		else
		{
			std::cout << "contradictory arrangement";
		}

	}
}
