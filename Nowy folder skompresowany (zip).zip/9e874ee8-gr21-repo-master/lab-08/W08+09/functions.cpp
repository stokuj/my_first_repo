/** @file */

/*
FUNDAMENTALS OF COMPUTER PROGRAMMING
 
Lecture 8: singly linked list 
 
 */

#define debug(x)  std::cerr << "(" << __LINE__ << ") " << #x << " == " << (x) << std::endl


#include <iostream>

#include "functions.h"
#include "structures.h"

void addEndRec (item * & pH, const type & value)
{
    if (not pH)
        pH = new item { value, 0 };
    else 
        addEndRec(pH->pNext, value);
}

void printEndRec(item* pH, std::ostream& ss)
{
    if (pH)
    {
        printEndRec(pH->pNext, ss);
        ss << pH->value << " ";
    }
}


void printBeginningRec(item* pH, std::ostream& ss)
{
    if (pH)
    {
        ss << pH->value << " ";
        printBeginningRec(pH->pNext, ss);
    }
}


void addEndRec(item *& pH, const type & value)
{
    if (not pH) // empty list
        pH = new item { value, 0 };
    else 
        addEndRec(pH->pNext, value);
}


void addEndIter(item * & pH, const type& value)
{
    if (not pH) // empty list
        pH = new item { value, 0 };
    else // not empty list
    {
        auto p = pH;
        
        while ( p->pNext )
            p = p->pNext;
        
        p->pNext = new item {value, 0};
    }
}


void removeIter(item * & pH)
{
    while ( pH )
    {
        auto pSuccessor = pH->pNext;
        delete pH;
        pH = pSuccessor;
    }
}


void printBeginningIter(item*  pH)
{
    
    // original version 1;
//     auto /* item *  */ p = pHead;
//     
//     while (p != nullptr)
//     {
//         std::cout << p->value << " ";
//         p = p->pNext;
//     }
    
    
    // sophisticated version 2:
    while (pH)
    {
        std::cout << pH->value << " ";
        pH = pH->pNext;
    }
}



void addBeginning(item *& pH, const type & v)
{
    // version 1;
//     if (pH == nullptr) // empty list
//     {
//         item * pNew = new item;
//         (*pNew).value = v;
//         pNew->pNext = nullptr;
//         pH = pNew;
//     }
//     else // non empty list
//     {
//         item * pNew = new item;
//         (*pNew).value = v;
//         pNew->pNext = pH;
//         pH = pNew;
//     }
    
    
//     // more sophisticated version 2;
//     
//     if (pH == nullptr) // empty list
//     {
//         item * pNew = new item;
//         (*pNew).value = v;
//         pNew->pNext = pH;
//         pH = pNew;
//     }
//     else // non empty list
//     {
//         item * pNew = new item;
//         (*pNew).value = v;
//         pNew->pNext = pH;
//         pH = pNew;
//     }

    // more sophisticated version 3
    
//     item * pNew = new item;
//     (*pNew).value = v;
//     pNew->pNext = pH;
//     pH = pNew;

    // more sophisticated version 4
    
//     item * pNew = new item {v, pH};
//     pH = pNew;

    // more sophisticated version 5
    
    pH = new item {v, pH};
}


int * concatenate(const int* a1, const int s1, const int* a2, const int s2)
{
    int * pResult = new int [s1 + s2];
    
    for (int i = 0; i < s1; i++)
        pResult[i] = a1[i];
    
    for (int i = 0; i < s2; i++)
        pResult[s1 + i] = a2[i];
    
    return pResult;
}
