/** @file */

/*
FUNDAMENTALS OF COMPUTER PROGRAMMING
 
Lecture 7 & 8: singly linked list

*/


#ifndef STRUCTURES_H
#define STRUCTURES_H

/** type of data stored in a list */
typedef int type; 

/** item of a singly linked list */
struct item
{
   type value;   ///< value stored in an item
   item * pNext; ///< pointer to the next item
};

#endif 
