/** @file */

/*
FUNDAMENTALS OF COMPUTER PROGRAMMING

Lecture 7 & 8: singly linked list

 */

#define debug(x)  std::cerr << "(" << __LINE__ << ") " << #x << " == " << (x) << std::endl

#include <iostream>
#include <fstream>

#include "functions.h"
#include "structures.h"


int main ()
{
   // HEAP VARIABLES

   int * p = new int;
   *p = 5;
   debug(*p);
//
   delete p;
   p = nullptr;
   p = 0;
   // double deletion:

   delete p;


//    return 0;

   int variable = 10;
   int * pArray = new int [variable];

   pArray[0] = 5;
   *(pArray + 6) = 7;


   delete [] pArray;      // for arrays use delete []

   // dynamic array example:

   int evens [4] = {2, 4, 6, 8};
   int odds  [3] = {1, 3, 5};

   int * pEvens_Odds = concatenate (evens, 4, odds, 3);

   for (int i = 0; i < 7; i++)
       std::cout << pEvens_Odds[i] << " ";
   std::cout << std::endl;

   delete [] pEvens_Odds; // we have to delete the array to avoid memory leaks

//    return 0;


    // SINGLY LINKED LIST

    debug(sizeof(type) + sizeof (item *));
    debug(sizeof(item));

//     return 0;

    item * pHead = nullptr;   // empty list

    for (int i : { 5, 2, 8, 1, 0, 6, 3 } )
        addBeginning (pHead, i);  // add item at the beginning

//     return 0;

    printBeginningIter(pHead);  // print values of items from the beginning
    std::cout << std::endl;
     printBeginningIter(pHead);   // test if the list is not corrupted by the previous printing
     std::cout << std::endl;


    removeIter(pHead);  // remove all items iteratively
    removeIter(pHead);  // try to call again, check if pHead invalidated

    for (int i : { 5, 2, 8, 1, 0, 6, 3 } )
        addEndIter (pHead, i);  // add at the end iteratively

    printBeginningIter(pHead);
    std::cout << std::endl;
    removeIter(pHead);

//     return 0;


//    for (int i : { -5,-2, -8, -1, -0, -6, -3 } )
//        addEndRec (pHead, i);
//
//    printBeginningIter(pHead);  // print iteratively from the beginning
//    std::cout << std::endl;
//
////    printBeginningRec(pHead, std::cout);  // print recursively from the beginning
////    std::cout << std::endl;
//
//    printEndRec(pHead, std::cout);    // print recursively from the end
//    std::cout << std::endl;


//      removeIter(pHead);



    // print list to file stream
    std::ofstream file_stream ("numbers");
    if (file_stream)
    {
        file_stream << "numbers (beg -> end):" << std::endl;
        printBeginningRec(pHead, file_stream);
        file_stream << std::endl;
        file_stream << "numbers (end -> beg):" << std::endl;
        printEndRec(pHead, file_stream);
        file_stream.close();
    }


    removeIter(pHead);  // remove iteratively

    for (int i : { 5, 2, 8, 1, 0, 6, 3 } )
        addEndRec (pHead, i);  // add at the end (recursively)


//    removeBeginningRec(pHead);  // remove all items from the beginning (recursively)
//      return 0;

//    removeBeginningRec(pHead);  // and once again -- simple test
//
//    for (int i : { 5, 2, 8, 1, 0, 6, 3 } )
//        addEndRec (pHead, i);


//    removeEndRec(pHead);  // remove all items from the end (recursively)
//    removeEndRec(pHead); 0xff0f10
//    item * pSucc = nullptr;
//    std::cout << pSucc->value);
//    item * foundI = findI( pHead, 3);
//    item * foundR = findR( pHead, 5);
//    item * prediI = PredI( pHead, pSucc);
//    item * prediR = PredR( pHead, pSucc);

    removeR(pHead, pHead->pNext);
//    removeR(pHead, pHead);
    printBeginningIter(pHead);
    return 0;

}

// Ubi sunt qui ante nos fuerunt?
