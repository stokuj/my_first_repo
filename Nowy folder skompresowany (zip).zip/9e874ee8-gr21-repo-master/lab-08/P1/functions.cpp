/** @file */

/*
FUNDAMENTALS OF COMPUTER PROGRAMMING

Lecture 8: singly linked list

 */

#define debug(x)  std::cerr << "(" << __LINE__ << ") " << #x << " == " << (x) << std::endl


#include <iostream>

#include "functions.h"
#include "structures.h"

void addEndRec (item * & pH, const type & value)
{
    if (not pH)
        pH = new item { value, 0 };
    else
        addEndRec(pH->pNext, value);
}

void printEndRec(item* pH, std::ostream& ss)
{
    if (pH)
    {
        printEndRec(pH->pNext, ss);
        ss << pH->value << " ";
    }
}


void printBeginningRec(item* pH, std::ostream& ss)
{
    if (pH)
    {
        ss << pH->value << " ";
        printBeginningRec(pH->pNext, ss);
    }
}


//void addEndRec(item *& pH, const type & value)
//{
//    if (not pH) // empty list
//        pH = new item { value, 0 };
//    else
//        addEndRec(pH->pNext, value);
//}


void addEndIter(item * & pH, const type& value)
{
    if (not pH) // empty list
        pH = new item { value, 0 };
    else // not empty list
    {
        auto p = pH;

        while ( p->pNext )
            p = p->pNext;

        p->pNext = new item {value, 0};
    }
}


void removeIter(item * & pH)
{
    while ( pH )
    {
        auto pSuccessor = pH->pNext;
        delete pH;
        pH = pSuccessor;
    }
}


void printBeginningIter(item*  pH)
{

    // original version 1;
//     auto /* item *  */ p = pHead;
//
//     while (p != nullptr)
//     {
//         std::cout << p->value << " ";
//         p = p->pNext;
//     }


    // sophisticated version 2:
    while (pH)
    {
        std::cout << pH->value << " ";
        pH = pH->pNext;
    }
}



void addBeginning(item *& pH, const type & v)
{
    // version 1;
//     if (pH == nullptr) // empty list
//     {
//         item * pNew = new item;
//         (*pNew).value = v;
//         pNew->pNext = nullptr;
//         pH = pNew;
//     }
//     else // non empty list
//     {
//         item * pNew = new item;
//         (*pNew).value = v;
//         pNew->pNext = pH;
//         pH = pNew;
//     }


//     // more sophisticated version 2;
//
//     if (pH == nullptr) // empty list
//     {
//         item * pNew = new item;
//         (*pNew).value = v;
//         pNew->pNext = pH;
//         pH = pNew;
//     }
//     else // non empty list
//     {
//         item * pNew = new item;
//         (*pNew).value = v;
//         pNew->pNext = pH;
//         pH = pNew;
//     }

    // more sophisticated version 3

//     item * pNew = new item;
//     (*pNew).value = v;
//     pNew->pNext = pH;
//     pH = pNew;

    // more sophisticated version 4

//     item * pNew = new item {v, pH};
//     pH = pNew;

    // more sophisticated version 5

    pH = new item {v, pH};
}


int * concatenate(const int* a1, const int s1, const int* a2, const int s2)
{
    int * pResult = new int [s1 + s2];

    for (int i = 0; i < s1; i++)
        pResult[i] = a1[i];

    for (int i = 0; i < s2; i++)
        pResult[s1 + i] = a2[i];

    return pResult;
}

void removeR(item *&pH, const item * pToRemove)
{
        if (pH == pToRemove) // 1 situation
        {
            pH = pH->pNext;
            delete pToRemove;
            return;
        }
        if ( pH != nullptr)
        {
            return removeR(pH, pH->pNext);
        }

}
void remove(item *&pH, const item * pToRemove)
{
    if (not pH) // empty list
    {
        return;
    }
    else    // no empty list
    {
        if (pH == pToRemove) // 1 situation
        {
            pH = pH->pNext;
            delete pToRemove;
        }
        else
        {
            while (pH)
            {
                if (pH->pNext == pToRemove)             // 2 and 3 situation
                {
//                    if (pToRemove->pNext == nullptr)    // 3 situation
//                    {
//                        pH->pNext = nullptr;
//                        delete pToRemove;
//                    }
//                    else                                // 2 situation
//                    {
                        pH->pNext = pToRemove->pNext;
                        delete pToRemove;
                        return;
//                    }
                }
                else
                {
                   pH = pH->pNext;
                }
            }
        }
    }
    return;

}
item * findI( item * pH, const type & value)
{

    if (not pH) // empty list
    {

        pH = nullptr;
    }
    else   // no empty list
    {


        while(pH != nullptr)
        {

            if ( value == (pH->value))
            {
            std::cout <<"(I) Value: "<< value <<"  Adress: "<< pH   <<std::endl;
            }
            pH = pH->pNext;
        }
    }
}

item * findR( item * pH, const type & value)
{
    if (not pH) // empty list
    {

        pH = nullptr;
    }
    else   // no empty list
    {
        if ( value == (pH->value))
        {
        std::cout <<"(R) Value: "<< value <<"  Adress: "<< pH   <<std::endl;
        }
        findR(pH->pNext, value);

    }
}
item * PredI( item * pH, item * pSucc)
{

    if (not pH) // empty list
    {

        return pH = nullptr;
    }
    else   // no empty list
    {
        while(pH != nullptr)
        {

            if ((pH->pNext) == pSucc )
            {
            std::cout <<"(I) Adress: "<< pH   <<std::endl;
            }
            return pH = pH->pNext;
        }
    }
    // What does the function return?
}
item * PredR( item * pH, item * pSucc)
{

    if (not pH) // empty list
    {

        return pH = nullptr;
    }
    else   // no empty list
    {

        if ((pH->pNext) == pSucc )
        {
            std::cout <<"(R) Adress: "<< pH   <<std::endl;
        }
        return  PredR(pH->pNext, pSucc);

    }
    // What does the function return?
}
