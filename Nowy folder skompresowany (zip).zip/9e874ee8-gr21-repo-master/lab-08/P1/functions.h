/** @file */

/*
FUNDAMENTALS OF COMPUTER PROGRAMMING

Lecture 8: singly linked list

 */

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include "structures.h"

item * findI( item * pH, const type & value);
item * findR( item * pH, const type & value);
item * PredI( item * pH, item * pSucc);
item * PredR( item * pH, item * pSucc);



void remove(item *&pH, const item * pToRemove);
void removeR(item *&pH, const item * pToRemove);



/** The function concatenated two arrays.
@param a1 address of the first array
@param s1 size of the first array
@param a2 address of the second array
@param s2 size of the second array
@return address of a new array that hold copies of values from the first array and then from the second array
@warning The function allocates memory! */
int * concatenate (const int * a1, const int s1,
                   const int * a2, const int s2);

/** The function add a value at the beginning of a singly linked list.
@param[in,out] pHead pointer to the first item in a singly linked list
@param value value to add
*/
void addBeginning (item * & pHead, const type & value);

/** The function prints all items from the first to the last iteratively.
@param pHead pointer to the first item in a singly linked list
*/
void printBeginningIter (item * pHead);

/** The function prints all items from the first to the last iteratively.
@param pHead pointer to the first item in a singly linked list
@param[in,out] ss output stream to print into
*/
void printBeginningIter (item * pHead, std::ostream & ss);

/** The function removes all item iteratively.
@param[in,out] pHead pointer to the first item in a singly linked list. After deletion of all item in the list pHead is set nullptr.
*/
void removeIter (item * & pH);

/** The function add a value at the end of a singly linked list (iteratively).
@param[in,out] pHead pointer to the first item in a singly linked list
@param value value to add
*/
void addEndIter (item * & pHead, const type & value);

/** The function add a value at the end of a singly linked list (recursively).
@param[in,out] pHead pointer to the first item in a singly linked list
@param value value to add
*/
void addEndRec (item * & pHead, const type & value);

/** The function prints all items from the first to the last (recursively).
@param pHead pointer to the first item in a singly linked list
@param[in,out] ss output stream to print into
*/
void printBeginningRec (item * pHead, std::ostream & ss);

/** The function prints all items from the last to the first (recursively).
@param pHead pointer to the first item in a singly linked list
@param[in,out] ss output stream to print into
*/
void printEndRec (item * pHead, std::ostream & ss);

/** The function removes all items from the first to the last (recursively).
@param[in,out] pHead pointer to the first item in a singly linked list
*/
void removeBeginningRec (item * & pHead);

/** The function removes all items from the last to the first (recursively).
@param[in,out] pHead pointer to the first item in a singly linked list
*/
void removeEndRec (item * & pHead);

#endif
