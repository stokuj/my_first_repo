#include <math.h>
#include <iostream>
#include <iomanip>

int main()
{
	double x = 1;


	for (double i = 0; i <= 20; i++)
	{

		std::cout << std::fixed << std::setprecision(1)  << "Sin" << i/10 << ":";
		std::cout << std::fixed << std::setprecision(3)  << " "<<sin(x*i/10) << std::endl;

	}

}
