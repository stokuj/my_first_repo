﻿#include "pch.h"
#include <iostream>
#include <iomanip>

int main()
{
	int n ;

	std::cout << "Enter n: ";
	std::cin >> n;
	const int W = 5;

    std::cout << "    "<< 0 << "|";

	for (int k = 1; k <= n; k++)
	{
		std::cout << std::setw(W) << k << "" ;
	}

	std::cout << std::endl << "-----|";

	for (int k = 1; k <= n; k++)
	{
		std::cout << std::setw(1) << "-----";

	}

	std::cout << std::endl;

	for (int i = 1; i <= n; i++)
	{
		std::cout << std::setw(W) << i << "|" ;

		for (int j = 1; j <= n; j++)
		{

			std::cout << std::setw(W)<< j*i ;
		}

		std::cout << std::endl;
	}


}

