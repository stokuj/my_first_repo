#include <iostream>
#include <math.h>
#include <cmath>

using namespace std;

typedef double(*ptof)(double);

double f(double x)
{
//    return sin(x);
//    return (pow(x,2)/4);

    return  x;
}

double area( const double a, const double b, const double n)
{
    double a_to_b = (b - a);
    double with = a_to_b / n;
    double area_r ;
    double total_area_r;

    for (double x=a; x < b; x = x + with )
    {
        area_r = with * f(x);
        total_area_r = total_area_r + area_r;
    }
    return total_area_r;
}

double area( const double a, const double b, const double n, ptof p) //  double (*p)(double)
{
    double a_to_b = (b - a);
    double with = a_to_b / n;
    double area_r ;
    double total_area_r;

    for (double x=a; x < b; x = x + with )
    {
        area_r = with * p(x);
        total_area_r = total_area_r + area_r;
    }
    return total_area_r;
}
//double area( const double a, const double b, const double n,double (*p)(double)) //  double (*p)(double)
//{
//    double a_to_b = (b - a);
//    double with = a_to_b / n;
//    double area_r ;
//    double total_area_r;
//
//    for (double x=a; x < b; x = x + with )
//    {
//        area_r = with * p(x);
//        total_area_r = total_area_r + area_r;
//    }
//    return total_area_r;
//}


int main()
{
    double a = 0;
    double b = 3;
    double n = 1000000;

    ptof array_of_ptof[] = {sin,cos,f};
//    double (*array[])(double) = {sin,cos,f};

    for ( int i = 0; i < sizeof(array_of_ptof);i++)
    {
        array_of_ptof[i];
    }

    cout << area(a,b,n)<<endl;
    cout << area(a,b,n,f);
}
