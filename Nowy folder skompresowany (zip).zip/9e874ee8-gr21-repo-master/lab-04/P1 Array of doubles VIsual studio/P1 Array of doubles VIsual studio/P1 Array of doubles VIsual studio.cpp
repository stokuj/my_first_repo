﻿

#include "pch.h"
#include <iostream>
#include <random>
#include <chrono>

//using namespace std;

void fill(double arr[], const int size_of_arr)
{

	for (int i = 0; i < size_of_arr; i++)
	{
		std::default_random_engine engine;
		engine.seed(std::chrono::system_clock::now().time_since_epoch().count());
		std::normal_distribution<double> distro(170, 20);
		double random = distro(engine);

		arr[i] = random;
		std::cout << arr[i] << std::endl;
	}

}


int main()
{
	const int size_of_arr;
	std::cin >> size_of_arr;

	double arr[size_of_arr];

	fill(arr, size_of_arr);

	return 0;
}
