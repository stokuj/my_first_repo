#include <iostream>

#include <random>    // To use random numbers

#include <chrono>    // To use random numbers



//using namespace std;



// selection sort algoritm





void fill(double arr[], const int size_of_arr)

{

    std::default_random_engine engine;

    engine.seed(std::chrono::system_clock::now().time_since_epoch().count());

    std::normal_distribution<double> distro (170,20);
    for ( int i = 0; i < size_of_arr; i++)

    {

        double random = distro(engine);

        arr[i] = random;

    }

}



void print(double arr[], const int size_of_arr)

{

    for ( int i = 0; i < size_of_arr; i++)

    {

        std::cout << arr[i]<< ", ";

    }

}
void min_of_arr(double arr[], const int size_of_arr)

{

<<<<<<< HEAD


    for (int i = 0; i< size_of_arr-1   ; i++)

    {



        int index_of_min_number = i;

        for ( int j = i+1; j < size_of_arr; j++)

        {

            if (arr[j] < arr[index_of_min_number])

            {

                index_of_min_number = j;

            }

        }

        double temp = arr[index_of_min_number];

        arr[index_of_min_number] = arr[i];

        arr[i] = temp;



        std::cout << std::endl;

        std::cout << "The lowest value of array is: "<< arr[index_of_min_number] << std::endl;

    }

=======
    for (int i = 0; i< size_of_arr-1   ; i++)
    {

        int index_of_min_number = i;
        for ( int j = i+1; j < size_of_arr; j++)
        {
            if (arr[j] < arr[index_of_min_number])
            {
                index_of_min_number = j;
            }
        }
        double temp = arr[index_of_min_number];
        arr[index_of_min_number] = arr[i];
        arr[i] = temp;

        std::cout << std::endl;
        std::cout << "The lowest value of array is: "<< arr[index_of_min_number] << std::endl;
    }
>>>>>>> cd0479b4da5dafc192f4554e172e687c7aa58bd7
}



int main()

{

    const int size_of_arr = 5;

    double arr[size_of_arr];
//    double arr[size_of_arr] = {100,200,300,400,500};

//    double arr[size_of_arr] = {100,200,300,400,500};



    fill(arr,size_of_arr);           //fill array



    print(arr,size_of_arr);          // print array



    std::cout << std::endl;

    min_of_arr(arr,size_of_arr);     //print min value of array
    std::cout << std::endl;

    print(arr,size_of_arr);
<<<<<<< HEAD

    std::cout << std::endl;

=======
    std::cout << std::endl;
>>>>>>> cd0479b4da5dafc192f4554e172e687c7aa58bd7
    return 0;

}
