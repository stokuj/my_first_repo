﻿

#include <iostream>



int main()
{
    std::cout << "Witaj w moim programie.\n";


}

