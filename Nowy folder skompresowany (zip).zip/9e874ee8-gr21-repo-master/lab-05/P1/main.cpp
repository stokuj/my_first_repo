<<<<<<< HEAD
#include <iostream>
#include <random>
#include <chrono>

using namespace std;

struct point
{
    double x,y;
};

struct triangle
{
    double a,b,c;
};

point get_point(std::default_random_engine &engine)
{

    std::uniform_real_distribution<double> distro (0,10);
    point p;
    p.x = distro(engine);
    p.y = distro(engine);
    return p;
}

void print(const point &p)
{
    cout << p.x <<" "<< p.y;
}

void fill(point arr[],const int SIZE,std::default_random_engine &engine)
{
    for (int i = 0 ; i < SIZE;i++)
    {
        arr[i] = get_point(engine);
    }

    for (int i = 0 ; i < SIZE;i++)
    {
        cout << arr[i].x <<" "<< arr[i].y << endl;

    }
}

triangle find_the_largest(point arr[],const int SIZE)
{
    triangle t;
    double max_t; ab,bc,ca;
    for (int i = 0; i<SIZE ;i++)
    {
        for (int j = 0; j<SIZE ;j++)
        {
            for (int k = 0; k<SIZE ;k++)
            {
                t.a = arr[i];
                t.b = arr[j];
                t.c = arr[k];

                ab = side(t.a,t.b);
                bc = side(t.b,t.c);
                ca = side(t.c,t.a);
                if (( ab+bc+ca ) > max_t)
                {
                    max_t = (ab+bc+ca);
                }
            }
        }
    }
}

double side(const point &c,const point &d);
{
    return sqrt( (c.x - d.x)*(c.x - d.x) + (c.y - d.y)*(c.y - d.y) );
}

int main()
{
    const int SIZE = 3;
    point arr[SIZE];

    std::default_random_engine engine;
    engine.seed(std::chrono::system_clock::now().time_since_epoch().count());

    point p = get_point(engine);
//    print(p);             //1

    fill(arr,SIZE,engine);  //2

    triange(arr,SIZE);      //3
    return 0;
}
=======
    #include <iostream>
    #include <random>
    #include <chrono>
    #include <iomanip>

    using namespace std;

    struct point
    {
        double x,y;
    };

    struct triangle
    {
        point a,b,c;
    };

    point get_point(std::default_random_engine &engine)
    {

        std::uniform_real_distribution<double> distro (0,10);
        point p;
        p.x = distro(engine);
        p.y = distro(engine);
        return p;
    }

    void print(const point &p)
    {
        cout << p.x <<" "<< p.y;
    }

    void fill(point arr[],const int SIZE,std::default_random_engine &engine)
    {
        for (int i = 0 ; i < SIZE;i++)
        {
            arr[i] = get_point(engine);
        }

        for (int i = 0 ; i < SIZE;i++)
        {
            cout << "Point"<<i+1<<":  " << fixed<< setw(5) << setprecision(5)  << arr[i].x <<"   "<< arr[i].y << endl;

        }
//        arr[0].x =  2; // 90stopni //
//        arr[0].y =  2;
//
//        arr[1].x =  4;
//        arr[1].y =  2;
//
//        arr[2].x =  4;
//        arr[2].y =  -3;
    }

    double side(const point &c,const point &d)
    {
        return sqrt( (c.x - d.x)*(c.x - d.x) + (c.y - d.y)*(c.y - d.y) );
    }

    triangle find_the_largest(point arr[],const int SIZE)
    {
        triangle t;
        triangle t_m;
        double p_, pole;
        double ab, bc, ca;
        double pole_max = 0;
        double ab_of_max, bc_of_max, ca_of_max;


        for (int i = 0; i<SIZE ;i++)
        {
            for (int j = 0; j<SIZE ;j++)
            {
                for (int k = 0; k<SIZE ;k++)
                {
                    t.a = arr[i];
                    t.b = arr[j];
                    t.c = arr[k];

                    ab = side(t.a,t.b);
                    bc = side(t.b,t.c);
                    ca = side(t.c,t.a);

                    p_ = (ab+bc+ca)/2;
                    pole = sqrt(p_ *(p_-ab)*(p_-bc)*(p_-ca));

                    if ( pole > pole_max )
                    {
                        pole_max = pole;
                        ab_of_max = ab;
                        bc_of_max = bc;
                        ca_of_max = ca;
                        t_m.a = t.a;
                        t_m.b = t.b;
                        t_m.c = t.c;
                    }
                }
            }
        }

        cout << endl;
        cout << "Point and sides of triangle with bigest area: " << endl;
        cout << "Point1: " << t_m.a.x << t_m.a.y << endl;
        cout << "Point2: " << t_m.b.x << t_m.a.y << endl;
        cout << "Point3: " << t_m.c.x << t_m.a.y << endl;

        cout << endl;
        cout << "AB: " << ab_of_max <<endl;
        cout << "BC: " << bc_of_max <<endl;
        cout << "CA: " << ca_of_max <<endl;

        cout << endl;
        cout <<"Triangle Area: " <<pole_max<<endl;
    }

    int main()
    {
        const int SIZE = 6;
        point arr[SIZE];

        std::default_random_engine engine;
        engine.seed(std::chrono::system_clock::now().time_since_epoch().count());

        point p = get_point(engine);        //1P


        fill(arr,SIZE,engine);              //2

        find_the_largest(arr,SIZE);         //3
        return 0;
    }

