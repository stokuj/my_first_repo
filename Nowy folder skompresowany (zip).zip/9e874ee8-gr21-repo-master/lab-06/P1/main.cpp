#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <iomanip>
#include <vector>
#include <string>
#include <math.h>

using namespace std;

size_t wc(istream &s)
{
    string word;
    size_t cnt = 0;

    while( s >> word )
        cnt++;

    return  cnt;
}

void count_characters(istream &s, size_t characters[26])
{
    char c;

    while(s.get(c))
        {
            c = tolower(c);
            // range
            if((c >= 'a') && (c<='z'))
            {
                characters[c-'a']++;
            }
        }
    for (int i = 0; i<26;i++)
        {
            cout<<characters[i]<<endl;
        }

}

void print_histogram(size_t characters[26], const int MAX)
{
    // find max in array
    int max_val_in_array = characters[0];
    for (int i = 0; i < 26; i++)
    {
        if (characters[i] > max_val_in_array)
        {
            max_val_in_array = characters[i];
        }
    }

    // calc scale
    size_t mno = max_val_in_array / 100;


    char x;

    for ( int i = 0; i < 26; i++)
    {
        x = i + 97;
        cout << x<<": ";
        cout << setw(7)<< characters[i]<<"  ";
        for ( int ile = 1; ile < ceil(characters[i]/mno); ile ++  )
        {
            cout <<"*";
        }
        cout <<"*";
        cout << endl;
    }

}

int main()
{
    ifstream s("texts/hamlet.txt");

    if (s)
    {
        size_t characters[26] = {};
//        cout << wc(s)<< endl;
        count_characters(s,characters);
        print_histogram(characters, 10);
        s.close();
    }
    else
    {
        cout << "Fille was not opened!";
    }

    return 0;
}
